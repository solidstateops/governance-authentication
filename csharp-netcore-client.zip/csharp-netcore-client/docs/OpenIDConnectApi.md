# SolidStateOps.Service.Api.OpenIDConnectApi

All URIs are relative to *https://auth.gravitee.io//oidc*

Method | HTTP request | Description
------------- | ------------- | -------------
[**RegisterClientIdDelete**](OpenIDConnectApi.md#registerclientiddelete) | **DELETE** /register/{client_id} | Delete a registred client.
[**RegisterClientIdGet**](OpenIDConnectApi.md#registerclientidget) | **GET** /register/{client_id} | Get a registred client.
[**RegisterClientIdPatch**](OpenIDConnectApi.md#registerclientidpatch) | **PATCH** /register/{client_id} | Patch a registred client.
[**RegisterClientIdRenewSecretPost**](OpenIDConnectApi.md#registerclientidrenewsecretpost) | **POST** /register/{client_id}/renew_secret | Renew the client secret of a registred client.
[**RegisterPost**](OpenIDConnectApi.md#registerpost) | **POST** /register | Register (create) a new client.
[**UserinfoGet**](OpenIDConnectApi.md#userinfoget) | **GET** /userinfo | Get claims about the authenticated End-User
[**UserinfoPost**](OpenIDConnectApi.md#userinfopost) | **POST** /userinfo | Get claims about the authenticated End-User
[**WellKnownJwksJsonGet**](OpenIDConnectApi.md#wellknownjwksjsonget) | **GET** /.well-known/jwks.json | Get JSON Web Key Set
[**WellKnownOpenidConfigurationGet**](OpenIDConnectApi.md#wellknownopenidconfigurationget) | **GET** /.well-known/openid-configuration | Get OpenID Provider configuration information


<a name="registerclientiddelete"></a>
# **RegisterClientIdDelete**
> ClientRegistrationResponse RegisterClientIdDelete (string authorization, string clientId)

Delete a registred client.

Delete a registred client.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using SolidStateOps.Service.Api;
using SolidStateOps.Service.Client;
using SolidStateOps.Service.Model;

namespace Example
{
    public class RegisterClientIdDeleteExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://auth.gravitee.io//oidc";
            var apiInstance = new OpenIDConnectApi(config);
            var authorization = "authorization_example";  // string | Bearer token obtained on the register process through the registration_access_token property giving access only to one client matching the client_id path parameter. An admin token can be also obtained through the client crendentials flow with as mandatory scope \"dcr_admin\".
            var clientId = "clientId_example";  // string | ID of the client

            try
            {
                // Delete a registred client.
                ClientRegistrationResponse result = apiInstance.RegisterClientIdDelete(authorization, clientId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling OpenIDConnectApi.RegisterClientIdDelete: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **string**| Bearer token obtained on the register process through the registration_access_token property giving access only to one client matching the client_id path parameter. An admin token can be also obtained through the client crendentials flow with as mandatory scope \&quot;dcr_admin\&quot;. | 
 **clientId** | **string**| ID of the client | 

### Return type

[**ClientRegistrationResponse**](ClientRegistrationResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **400** | Invalid Request |  -  |
| **401** | Invalid Token |  -  |
| **403** | Access forbidden |  -  |
| **204** | Client deleted |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="registerclientidget"></a>
# **RegisterClientIdGet**
> ClientRegistrationResponse RegisterClientIdGet (string authorization, string clientId)

Get a registred client.

See information about a registred client.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using SolidStateOps.Service.Api;
using SolidStateOps.Service.Client;
using SolidStateOps.Service.Model;

namespace Example
{
    public class RegisterClientIdGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://auth.gravitee.io//oidc";
            var apiInstance = new OpenIDConnectApi(config);
            var authorization = "authorization_example";  // string | Bearer token obtained on the register process through the registration_access_token property giving access only to one client matching the client_id path parameter. An admin token can be also obtained through the client crendentials flow with as mandatory scope \"dcr_admin\".
            var clientId = "clientId_example";  // string | ID of the client

            try
            {
                // Get a registred client.
                ClientRegistrationResponse result = apiInstance.RegisterClientIdGet(authorization, clientId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling OpenIDConnectApi.RegisterClientIdGet: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **string**| Bearer token obtained on the register process through the registration_access_token property giving access only to one client matching the client_id path parameter. An admin token can be also obtained through the client crendentials flow with as mandatory scope \&quot;dcr_admin\&quot;. | 
 **clientId** | **string**| ID of the client | 

### Return type

[**ClientRegistrationResponse**](ClientRegistrationResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **400** | Invalid Request |  -  |
| **401** | Invalid Token |  -  |
| **403** | Access forbidden |  -  |
| **200** | Claims about the registred client. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="registerclientidpatch"></a>
# **RegisterClientIdPatch**
> ClientRegistrationResponse RegisterClientIdPatch (string authorization, string clientId, ClientRegistrationRequest request)

Patch a registred client.

Update information about a registred client.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using SolidStateOps.Service.Api;
using SolidStateOps.Service.Client;
using SolidStateOps.Service.Model;

namespace Example
{
    public class RegisterClientIdPatchExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://auth.gravitee.io//oidc";
            var apiInstance = new OpenIDConnectApi(config);
            var authorization = "authorization_example";  // string | Bearer token obtained on the register process through the registration_access_token property giving access only to one client matching the client_id path parameter. An admin token can be also obtained through the client crendentials flow with as mandatory scope \"dcr_admin\".
            var clientId = "clientId_example";  // string | ID of the client
            var request = new ClientRegistrationRequest(); // ClientRegistrationRequest | 

            try
            {
                // Patch a registred client.
                ClientRegistrationResponse result = apiInstance.RegisterClientIdPatch(authorization, clientId, request);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling OpenIDConnectApi.RegisterClientIdPatch: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **string**| Bearer token obtained on the register process through the registration_access_token property giving access only to one client matching the client_id path parameter. An admin token can be also obtained through the client crendentials flow with as mandatory scope \&quot;dcr_admin\&quot;. | 
 **clientId** | **string**| ID of the client | 
 **request** | [**ClientRegistrationRequest**](ClientRegistrationRequest.md)|  | 

### Return type

[**ClientRegistrationResponse**](ClientRegistrationResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **400** | Invalid Request |  -  |
| **401** | Invalid Token |  -  |
| **403** | Access forbidden |  -  |
| **200** | Claims about the updated client. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="registerclientidrenewsecretpost"></a>
# **RegisterClientIdRenewSecretPost**
> ClientRegistrationResponse RegisterClientIdRenewSecretPost (string authorization, string clientId)

Renew the client secret of a registred client.

Renew the client secret of a registred client.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using SolidStateOps.Service.Api;
using SolidStateOps.Service.Client;
using SolidStateOps.Service.Model;

namespace Example
{
    public class RegisterClientIdRenewSecretPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://auth.gravitee.io//oidc";
            var apiInstance = new OpenIDConnectApi(config);
            var authorization = "authorization_example";  // string | Bearer token obtained on the register process through the registration_access_token property giving access only to one client matching the client_id path parameter. An admin token can be also obtained through the client crendentials flow with as mandatory scope \"dcr_admin\".
            var clientId = "clientId_example";  // string | ID of the client

            try
            {
                // Renew the client secret of a registred client.
                ClientRegistrationResponse result = apiInstance.RegisterClientIdRenewSecretPost(authorization, clientId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling OpenIDConnectApi.RegisterClientIdRenewSecretPost: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **string**| Bearer token obtained on the register process through the registration_access_token property giving access only to one client matching the client_id path parameter. An admin token can be also obtained through the client crendentials flow with as mandatory scope \&quot;dcr_admin\&quot;. | 
 **clientId** | **string**| ID of the client | 

### Return type

[**ClientRegistrationResponse**](ClientRegistrationResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **400** | Invalid Request |  -  |
| **401** | Invalid Token |  -  |
| **403** | Access forbidden |  -  |
| **200** | Claims about the updated client. |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="registerpost"></a>
# **RegisterPost**
> ClientRegistrationResponse RegisterPost (ClientRegistrationRequest request, string? authorization = null)

Register (create) a new client.

The Dynamic Client Registration (dcr) Endpoint is an OAuth 2.0 Protected Resource through which a new Client registration can be requested.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using SolidStateOps.Service.Api;
using SolidStateOps.Service.Client;
using SolidStateOps.Service.Model;

namespace Example
{
    public class RegisterPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://auth.gravitee.io//oidc";
            var apiInstance = new OpenIDConnectApi(config);
            var request = new ClientRegistrationRequest(); // ClientRegistrationRequest | 
            var authorization = "authorization_example";  // string? | Bearer token obtained through client crendentials flow with as mandatory scope \"dcr_admin\". Token required unless open dynamic client registration is enabled. (optional) 

            try
            {
                // Register (create) a new client.
                ClientRegistrationResponse result = apiInstance.RegisterPost(request, authorization);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling OpenIDConnectApi.RegisterPost: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **request** | [**ClientRegistrationRequest**](ClientRegistrationRequest.md)|  | 
 **authorization** | **string?**| Bearer token obtained through client crendentials flow with as mandatory scope \&quot;dcr_admin\&quot;. Token required unless open dynamic client registration is enabled. | [optional] 

### Return type

[**ClientRegistrationResponse**](ClientRegistrationResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **400** | Invalid Request |  -  |
| **401** | Invalid Token |  -  |
| **403** | Registration forbidden |  -  |
| **201** | Claims about the registred client |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="userinfoget"></a>
# **UserinfoGet**
> UserInfoResponse UserinfoGet (string authorization)

Get claims about the authenticated End-User

The UserInfo Endpoint is an OAuth 2.0 Protected Resource that returns Claims about the authenticated End-User.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using SolidStateOps.Service.Api;
using SolidStateOps.Service.Client;
using SolidStateOps.Service.Model;

namespace Example
{
    public class UserinfoGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://auth.gravitee.io//oidc";
            var apiInstance = new OpenIDConnectApi(config);
            var authorization = "authorization_example";  // string | To obtain the requested Claims about the End-User, the Client makes a request to the UserInfo Endpoint using an Access Token obtained through OpenID Connect Authentication

            try
            {
                // Get claims about the authenticated End-User
                UserInfoResponse result = apiInstance.UserinfoGet(authorization);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling OpenIDConnectApi.UserinfoGet: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **string**| To obtain the requested Claims about the End-User, the Client makes a request to the UserInfo Endpoint using an Access Token obtained through OpenID Connect Authentication | 

### Return type

[**UserInfoResponse**](UserInfoResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **400** | Invalid Request |  -  |
| **401** | Invalid Token |  -  |
| **200** | Claims about the authenticated End-User |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="userinfopost"></a>
# **UserinfoPost**
> UserInfoResponse UserinfoPost (string accessToken)

Get claims about the authenticated End-User

The UserInfo Endpoint is an OAuth 2.0 Protected Resource that returns Claims about the authenticated End-User.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using SolidStateOps.Service.Api;
using SolidStateOps.Service.Client;
using SolidStateOps.Service.Model;

namespace Example
{
    public class UserinfoPostExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://auth.gravitee.io//oidc";
            var apiInstance = new OpenIDConnectApi(config);
            var accessToken = "accessToken_example";  // string | To obtain the requested Claims about the End-User, the Client makes a request to the UserInfo Endpoint using an Access Token obtained through OpenID Connect Authentication

            try
            {
                // Get claims about the authenticated End-User
                UserInfoResponse result = apiInstance.UserinfoPost(accessToken);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling OpenIDConnectApi.UserinfoPost: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **accessToken** | **string**| To obtain the requested Claims about the End-User, the Client makes a request to the UserInfo Endpoint using an Access Token obtained through OpenID Connect Authentication | 

### Return type

[**UserInfoResponse**](UserInfoResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **400** | Invalid Request |  -  |
| **401** | Invalid Token |  -  |
| **200** | Claims about the authenticated End-User |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="wellknownjwksjsonget"></a>
# **WellKnownJwksJsonGet**
> JWKSetResponse WellKnownJwksJsonGet ()

Get JSON Web Key Set

JWKS endpoint containing the public keys used by OpenID Connect Relying Party to verify any JWT issued by the authorization server.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using SolidStateOps.Service.Api;
using SolidStateOps.Service.Client;
using SolidStateOps.Service.Model;

namespace Example
{
    public class WellKnownJwksJsonGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://auth.gravitee.io//oidc";
            var apiInstance = new OpenIDConnectApi(config);

            try
            {
                // Get JSON Web Key Set
                JWKSetResponse result = apiInstance.WellKnownJwksJsonGet();
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling OpenIDConnectApi.WellKnownJwksJsonGet: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**JWKSetResponse**](JWKSetResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | A JSON object that represents a set of JWKs |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="wellknownopenidconfigurationget"></a>
# **WellKnownOpenidConfigurationGet**
> OpenIDProviderMetadataResponse WellKnownOpenidConfigurationGet ()

Get OpenID Provider configuration information

Discovery endpoint used by OpenID Connect Relying Party to discover the End-User's OpenID Provider and obtain information needed to interact with it, including its OAuth 2.0 endpoint locations.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using SolidStateOps.Service.Api;
using SolidStateOps.Service.Client;
using SolidStateOps.Service.Model;

namespace Example
{
    public class WellKnownOpenidConfigurationGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://auth.gravitee.io//oidc";
            var apiInstance = new OpenIDConnectApi(config);

            try
            {
                // Get OpenID Provider configuration information
                OpenIDProviderMetadataResponse result = apiInstance.WellKnownOpenidConfigurationGet();
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling OpenIDConnectApi.WellKnownOpenidConfigurationGet: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**OpenIDProviderMetadataResponse**](OpenIDProviderMetadataResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | The OpenID Provider Metadata values |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

