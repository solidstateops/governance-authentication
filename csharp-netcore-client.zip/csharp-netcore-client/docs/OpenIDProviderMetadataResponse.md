# SolidStateOps.Service.Model.OpenIDProviderMetadataResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Issuer** | **string** | REQUIRED. URL using the https scheme with no query or fragment component that the OP asserts as its Issuer Identifier | [optional] 
**AuthorizationEndpoint** | **string** | REQUIRED. URL of the OP&#39;s OAuth 2.0 Authorization Endpoint | [optional] 
**TokenEndpoint** | **string** | URL of the OP&#39;s OAuth 2.0 Token Endpoint | [optional] 
**UserinfoEndpoint** | **string** | RECOMMENDED. URL of the OP&#39;s UserInfo Endpoint | [optional] 
**JwksUri** | **string** | REQUIRED. URL of the OP&#39;s JSON Web Key Set [JWK] document. | [optional] 
**RegistrationEndpoint** | **string** | RECOMMENDED. URL of the OP&#39;s Dynamic Client Registration Endpoint | [optional] 
**ScopesSupported** | **string** | RECOMMENDED. JSON array containing a list of the OAuth 2.0 [RFC6749] scope values that this server supports | [optional] 
**ResponseTypesSupported** | **string** | REQUIRED. JSON array containing a list of the OAuth 2.0 response_type values that this OP supports | [optional] 
**ResponseModesSupported** | **string** | OPTIONAL. JSON array containing a list of the OAuth 2.0 response_mode values that this OP supports | [optional] 
**GrantTypesSupported** | **string** | OPTIONAL. JSON array containing a list of the OAuth 2.0 Grant Type values that this OP supports | [optional] 
**AcrValuesSupported** | **string** | OPTIONAL. JSON array containing a list of the Authentication Context Class References that this OP supports | [optional] 
**SubjectTypesSupported** | **string** | REQUIRED. JSON array containing a list of the Subject Identifier types that this OP supports | [optional] 
**IdTokenSigningAlgValuesSupported** | **string** | REQUIRED. JSON array containing a list of the JWS signing algorithms (alg values) supported by the OP for the ID Token to encode the Claims in a JWT | [optional] 
**IdTokenEncryptionAlgValuesSupported** | **string** | OPTIONAL. JSON array containing a list of the JWE encryption algorithms (alg values) supported by the OP for the ID Token to encode the Claims in a JWT | [optional] 
**IdTokenEncryptionEncValuesSupported** | **string** | OPTIONAL. JSON array containing a list of the JWE encryption algorithms (enc values) supported by the OP for the ID Token to encode the Claims in a JWT | [optional] 
**UserinfoSigningAlgValuesSupported** | **string** | OPTIONAL. JSON array containing a list of the JWS signing algorithms (alg values) [JWA] supported by the UserInfo Endpoint to encode the Claims in a JWT | [optional] 
**UserinfoEncryptionAlgValuesSupported** | **string** | ROPTIONAL. JSON array containing a list of the JWE encryption algorithms (alg values) [JWA] supported by the UserInfo Endpoint to encode the Claims in a JWT | [optional] 
**UserinfoEncryptionEncValuesSupported** | **string** | OPTIONAL. JSON array containing a list of the JWE encryption algorithms (enc values) [JWA] supported by the UserInfo Endpoint to encode the Claims in a JWT | [optional] 
**RequestObjectSigningAlgValuesSupported** | **string** | OPTIONAL. JSON array containing a list of the JWS signing algorithms (alg values) supported by the OP for Request Objects | [optional] 
**RequestObjectEncryptionAlgValuesSupported** | **string** | OPTIONAL. JSON array containing a list of the JWE encryption algorithms (alg values) supported by the OP for Request Objects | [optional] 
**RequestObjectEncryptionEncValuesSupported** | **string** | OPTIONAL. JSON array containing a list of the JWE encryption algorithms (enc values) supported by the OP for Request Objects | [optional] 
**TokenEndpointAuthMethodsSupported** | **string** | OPTIONAL. JSON array containing a list of Client Authentication methods supported by this Token Endpoint | [optional] 
**TokenEndpointAuthSigningAlgValuesSupported** | **string** | OPTIONAL. JSON array containing a list of the JWS signing algorithms (alg values) supported by the Token Endpoint for the signature on the JWT | [optional] 
**DisplayValuesSupported** | **string** | OPTIONAL. JSON array containing a list of the display parameter values that the OpenID Provider supports | [optional] 
**ClaimTypesSupported** | **string** | OPTIONAL. JSON array containing a list of the Claim Types that the OpenID Provider supports | [optional] 
**ClaimsSupported** | **string** | RECOMMENDED. JSON array containing a list of the Claim Names of the Claims that the OpenID Provider MAY be able to supply values for | [optional] 
**ServiceDocumentation** | **string** | OPTIONAL. URL of a page containing human-readable information that developers might want or need to know when using the OpenID Provider | [optional] 
**ClaimsLocalesSupported** | **string** | OPTIONAL. Languages and scripts supported for values in Claims being returned, represented as a JSON array of BCP47 [RFC5646] language tag values | [optional] 
**UiLocalesSupported** | **string** | OPTIONAL. Languages and scripts supported for the user interface, represented as a JSON array of BCP47 [RFC5646] language tag values | [optional] 
**ClaimsParameterSupported** | **bool** | OPTIONAL. Boolean value specifying whether the OP supports use of the claims parameter, with true indicating support. If omitted, the default value is false | [optional] 
**RequestParameterSupported** | **bool** | OPTIONAL. Boolean value specifying whether the OP supports use of the request parameter, with true indicating support. If omitted, the default value is false | [optional] 
**RequestUriParameterSupported** | **bool** | OPTIONAL. Boolean value specifying whether the OP supports use of the request_uri parameter, with true indicating support. If omitted, the default value is true | [optional] 
**RequireRequestUriRegistration** | **bool** | OPTIONAL. Boolean value specifying whether the OP requires any request_uri values used to be pre-registered using the request_uris registration parameter | [optional] 
**OpPolicyUri** | **string** | OPTIONAL. URL that the OpenID Provider provides to the person registering the Client to read about the OP&#39;s requirements on how the Relying Party can use the data provided by the OP | [optional] 
**OpTosUri** | **bool** | OPTIONAL. URL that the OpenID Provider provides to the person registering the Client to read about OpenID Provider&#39;s terms of service | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

