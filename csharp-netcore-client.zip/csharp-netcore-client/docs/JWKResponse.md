# Org.OpenAPITools.Model.JWKResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Kty** | **string** | The \&quot;kty\&quot; (key type) parameter identifies the cryptographic algorithm family used with the key, such as \&quot;RSA\&quot; or \&quot;EC\&quot; | [optional] 
**Use** | **string** | The \&quot;use\&quot; (public key use) parameter identifies the intended use of the public key | [optional] 
**KeyOps** | **string** | The \&quot;key_ops\&quot; (key operations) parameter identifies the operation(s) for which the key is intended to be used | [optional] 
**Alg** | **string** | The \&quot;alg\&quot; (algorithm) parameter identifies the algorithm intended for use with the key | [optional] 
**Kid** | **string** | The \&quot;kid\&quot; (key ID) parameter is used to match a specific key | [optional] 
**X5u** | **string** | The \&quot;x5u\&quot; (X.509 URL) parameter is a URI [RFC3986] that refers to a resource for an X.509 public key certificate or certificate chain [RFC5280] | [optional] 
**X5c** | **string** | The \&quot;x5c\&quot; (X.509 certificate chain) parameter contains a chain of one or more PKIX certificates [RFC5280] | [optional] 
**X5t** | **string** | The \&quot;x5t\&quot; (X.509 certificate SHA-1 thumbprint) parameter is a base64url-encoded SHA-1 thumbprint (a.k.a. digest) of the DER encoding of an X.509 certificate [RFC5280] | [optional] 
**X5tS256** | **string** | The \&quot;x5t#S256\&quot; (X.509 certificate SHA-256 thumbprint) parameter is a base64url-encoded SHA-256 thumbprint (a.k.a. digest) of the DER encoding of an X.509 certificate [RFC5280] | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

