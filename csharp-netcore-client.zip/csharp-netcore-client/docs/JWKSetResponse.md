# SolidStateOps.Authentication.Service.Model.JWKSetResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Keys** | [**List&lt;JWKResponse&gt;**](JWKResponse.md) | The value of the \&quot;keys\&quot; parameter is an array of JWK values | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

