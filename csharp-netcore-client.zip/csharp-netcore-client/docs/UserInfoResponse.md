# SolidStateOps.Service.Model.UserInfoResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Sub** | **string** | Subject - Identifier for the End-User at the Issuer | [optional] 
**Name** | **string** | End-User&#39;s full name in displayable form including all name parts, possibly including titles and suffixes, ordered according to the End-User&#39;s locale and preferences | [optional] 
**GivenName** | **string** | Given name(s) or first name(s) of the End-User | [optional] 
**FamilyName** | **string** | Surname(s) or last name(s) of the End-User | [optional] 
**MiddleName** | **string** | Middle name(s) of the End-User | [optional] 
**Nickname** | **string** | Casual name of the End-User that may or may not be the same as the given_name | [optional] 
**PreferredUsername** | **string** | Shorthand name by which the End-User wishes to be referred to at the RP, such as janedoe or j.doe | [optional] 
**Profile** | **string** | URL of the End-User&#39;s profile page | [optional] 
**Picture** | **string** | URL of the End-User&#39;s profile picture | [optional] 
**Website** | **string** | URL of the End-User&#39;s Web page or blog | [optional] 
**Email** | **string** | End-User&#39;s preferred e-mail address | [optional] 
**EmailVerified** | **bool** | User at the time the verification was performed | [optional] 
**Gender** | **string** | End-User&#39;s gender | [optional] 
**Birthdate** | **string** | End-User&#39;s birthday, represented as an ISO 8601:2004 [ISO8601 2004] YYYY-MM-DD format | [optional] 
**Zoneinfo** | **string** | String from zoneinfo [zoneinfo] time zone database representing the End-User&#39;s time zone | [optional] 
**Locale** | **string** | End-User&#39;s locale, represented as a BCP47 [RFC5646] language tag | [optional] 
**PhoneNumber** | **string** | End-User&#39;s preferred telephone number | [optional] 
**PhoneNumberVerified** | **bool** | User at the time the verification was performed | [optional] 
**Address** | **string** | End-User&#39;s preferred postal address | [optional] 
**UpdatedAt** | **int** | Time the End-User&#39;s information was last updated | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

